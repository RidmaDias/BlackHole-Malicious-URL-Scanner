import React from "react";
import styled from "styled-components";

function About() {
  return (
    <Wrapper>
      <div class="green-contact-form p-5 bg-white">
        <div class="title-form mb-5">
          <h3>Get in touch</h3>
          <p>
            We’re very approachable and would love to speak to you. Feel free to
            call, send us an email, Tweet us or simply complete the enquiry
            form.
          </p>
        </div>

        <div class="form-box">
          <h4>Send Us a Message</h4>

          <form>
            <fieldset class="form-group">
              <label for="yourName">Your Name (required)</label>
              <input
                type="text"
                class="form-control"
                id="yourName"
                placeholder="Enter Your Name"
                required
              />
            </fieldset>

            <fieldset class="form-group">
              <label for="yourEmail">Email Adressess (required)</label>
              <input
                type="email"
                class="form-control"
                id="yourEmail"
                placeholder="Enter Your Email"
                required
              />
            </fieldset>

            <fieldset class="form-group">
              <label for="yourPhone">Telephone number</label>
              <input
                type="text"
                class="form-control"
                id="yourPhone"
                placeholder="Enter Your Phone"
              />
            </fieldset>

            <fieldset class="form-group">
              <label for="yourEmail">Your message (required)</label>
              <textarea class="form-control" rows="6"></textarea>
            </fieldset>
            <br />
            <button type="submit" class="btn btn-dark" required>
              SEND MESSAGE
            </button>
          </form>
        </div>
      </div>
    </Wrapper>
  );
}

const Wrapper = styled.section`
  font-family: "Raleway", sans-serif;
  margin-top: 50px;
  background: gainsboro;
  padding: 2rem;
  min-height: 100vh;

  .green-contact-form {
    width: 700px;
    margin: 0 auto;
    border-radius: 10px;
  }

  .title-form {
    max-width: 550px;
  }
`;

export default About;
