const mongoose = require("mongoose");
const IpSchema = new mongoose.Schema(
  {
    url: {
      type: String,
      required: [true, "Please provide ip"],
    }
  }
);

module.exports = mongoose.model("Job", IpSchema);
