const Ip = require("../models/Ip");
const { StatusCodes } = require("http-status-codes");
const { BadRequestError, UnauthenticatedError } = require("../errors");
const domainPing = require("domain-ping");
const ipdetails = require("node-ip-details");
var portscanner = require('portscanner');

const checkIp = async (req, res) => {
  const ip = req.body.url;


  domainPing(ip) // Insert the domain you want to ping
    .then((result) => {
      //   console.log(result);
      const ipInitialised = ipdetails.initialise({ ip: result.ip });
      // return all the information for the IP supplied
      ipInitialised
        .allInformation()
        .then((r) => {
          // console.log(r);
          portscanner.checkPortStatus(443, ip, function(error, status) {
            // Status is 'open' if currently in use or 'closed' if available
            console.log(status)
            res.status(StatusCodes.OK).json({ r, result, status });
          })
          console.log(r)
        })
        .catch((err) => console.error(err));
    })
    .catch((error) => {
      console.error(error);
    });
};

module.exports = {
  checkIp,
};
